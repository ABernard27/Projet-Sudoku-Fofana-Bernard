#' Affiche la grille de sudoku
#'
#' @param X
#' @return la grille
#'

sudoplot <- function(X){
  grid.table(X)
}

